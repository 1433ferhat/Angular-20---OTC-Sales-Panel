// src/app/services/product.service.ts
import { Injectable, inject, resource } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProductModel } from '@shared/models/product.model';
import { CategoryModel } from '@shared/models/category.model';
import { PaginateModel } from '@shared/models/paginate.model';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private http = inject(HttpClient);

  // Products resource with pagination
  productsResource = resource({
    loader: ({ page, size, search, categoryId }) => {
      const params = new URLSearchParams();
      params.set('page', page?.toString() || '1');
      params.set('size', size?.toString() || '50');
      if (search) params.set('search', search);
      if (categoryId) params.set('categoryId', categoryId);
      
      return this.http.get<PaginateModel<ProductModel>>(`api/products?${params}`);
    }
  });

  // Categories resourcea
  categoriesResource = resource({
    loader: () => this.http.get<CategoryModel[]>('api/categories'),
  });

  // Single product by ID
  productResource = resource({
    loader: ({ id }: { id: string }) =>
      this.http.get<ProductModel>(`api/products/${id}`),
  });

  // Search products by barcode
  searchByBarcodeResource = resource({
    loader: ({ barcode }: { barcode: string }) =>
      this.http.get<ProductModel[]>(`api/products/search?barcode=${barcode}`),
  });

  // Low stock products
  lowStockResource = resource({
    loader: ({ threshold = 10 }: { threshold?: number }) =>
      this.http.get<ProductModel[]>(
        `api/products/low-stock?threshold=${threshold}`
      ),
  });
}
